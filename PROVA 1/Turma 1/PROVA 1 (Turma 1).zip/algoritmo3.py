"""
    1) Identifique o algoritmo abaixo.
    2) Faça o mapeamento das variáveis (registre em comentário o propósito de cada uma delas).
    3) Há um erro no algoritmo. Identifique-o, descreva-o e corrija-o.
"""

def a(b):
    def c(d, e):
        f = d
        for g in range(d + 1, e + 1):
            if b[g] < b[f]:
                f = g
        return g
    for h in range(len(b) - 1):
        i = c(h + 1, len(b) - 1)
        if b[i] < b[h]:
            b[i], b[h] = b[h], b[i]