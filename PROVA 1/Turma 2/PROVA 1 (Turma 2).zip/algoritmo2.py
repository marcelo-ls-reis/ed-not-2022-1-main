"""
    1) Identifique o algoritmo abaixo.
    2) Faça o mapeamento das variáveis (registre em comentário o propósito de cada uma delas).
    3) Há um erro no algoritmo. Identifique-o, descreva-o e corrija-o.
"""

def z(y):
    while True:
        x = False
        for w in range(len(y) - 1):
            if y[w] > y[w + 1]:
                y[w], y[w + 1] = x[w], x[w + 1]
                x = True
        if not x:
            break