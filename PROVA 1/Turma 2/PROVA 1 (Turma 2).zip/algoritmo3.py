"""
    1) Identifique o algoritmo abaixo.
    2) Faça o mapeamento das variáveis (registre em comentário o propósito de cada uma delas).
    3) Há um erro no algoritmo. Identifique-o, descreva-o e corrija-o.
"""

def z(y, x):
    w = 0  
    u = len(y) - 1 
    while w <= u:
        t = (w + u) // 2 
        if x == y[u]:
            return t
        elif x > y[u]:
            w = t + 1
        else:
            u = t - 1
    return -1